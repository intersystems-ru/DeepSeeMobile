({

    baseUrl: '.',
    paths: {
        text: "lib/text",
        jquery: "lib/jquery-2.1.1"
    },
    name: "main",
    out: "main-build.js"
})