Installation
============
1. You need Node.JS and Phonegap. Install them:  
    * http://www.nodejs.org  
    * http://www.phonegap.com  
2. Run <code>phonegap build ios</code> in Terminal / Windows cmd
3. For documentation rebuilding use <code>jsdoc -c documentation/conf.json</code> 
